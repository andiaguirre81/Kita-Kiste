# KitaKiste v0.3
Mobiler PWA-Prototyp.

## Auf GitHub Pages veröffentlichen
1. Alle Dateien aus diesem ZIP entpacken und in das Repository **Kita-Kiste** hochladen.
2. GitHub → Settings → Pages.
3. Source: **Deploy from a branch**.
4. Branch: **main**, Ordner: **/(root)** → Save.
5. Nach kurzer Zeit zeigt GitHub dort die öffentliche Webadresse.

Enthalten: Suche, Filter, Schnellfilter, Favoriten, Zufallsidee, eigene lokale Ideen, PWA-App-Icon und Offline-Grundfunktion.
